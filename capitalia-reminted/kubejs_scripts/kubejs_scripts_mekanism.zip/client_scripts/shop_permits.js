// Localizes the shop permits
ClientEvents.lang("en_us", e => {

    e.add("adminshop.permit.advanced_research", "Advanced Researcher's License")
    e.add("adminshop.permit.industrial_trading", "Certificate of Industrial Trading")
    e.add("adminshop.permit.me_expert", "ME Expert Certification")

})