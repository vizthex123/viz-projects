+ is advantage
+- is advantage with a caveat (or two)
- is disadvantage

# Pretty Pipes
+ cheap
+ easy to set up and get sorting
+- auto-crafting (requires an external mod)
- no polymorphic itemsink system
- tag modules aren't very flexible (only supports a single tag, and requires a regular item module - so you can't have it sort the one tag + extra items)


# LaserIO
+ balanced cost
+ lasers are cool
- not quite what i wanted since it's more akin to EnderIO's conduits


# Mekanism
+ very flexible
- requires the industrial age
- it's mekanism