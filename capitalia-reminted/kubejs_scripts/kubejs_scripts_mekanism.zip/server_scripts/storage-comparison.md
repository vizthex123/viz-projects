+ is advantage
- is disadvantage

# Functional Storage
+ cheap and easy to set up
+ compacting drawers are great for ingots (and other items)
- doesn't support the modded wood types
- far too upgradable compared to what i want out of an early-game mass storage mod. Could just disable them, but still
- i've never liked drawers as much as barrels from a pure visual design standpoint
controller system is nice though, and allows it to work much better with AE2 (and other mods)


# Iron Chests: Restocked
+ has chests and barrels
+it's already installed lol
- they act like chests instead of modded barrels 
- far too upgradable compared to what i want out of an early-game mass storage mod. I disabled the higher tiers, but stil


# Mekanism Bins
+ cheap and easy to set up
- requires the industrial age


# NABBA
*removing this cuz i don't wanna deal with the lack of mining tags & large amount of upgrades*

+ has fluid tanks, apparently
+ auto-pickup upgrades
+ controller system like Functional Storage
- no default mining tools
- adds *far* too many upgrades and systems