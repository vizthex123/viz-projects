// Adds and changes recipes for Ender IO's content
ServerEvents.recipes(e => {
/*
    // Make Organic Black Dye use my carbon dust tag
    e.remove({id: "enderio:alloy_smelting/organic_black_dye"});
    e.remove({id: "enderio:alloy_smelting/organic_black_dye_double"});
    e.recipes.enderio.alloy_smelting("enderio:organic_black_dye", [Ingredient.of("#revolution:carbon_dust"), Ingredient.of("#forge:eggs")]).energy(1000).id("kubejs:organic_black_dye");
    e.recipes.enderio.alloy_smelting("2x enderio:organic_black_dye", [Ingredient.of("#revolution:carbon_dust", 2), "#forge:slimeballs"]).energy(1600).id("kubejs:organic_black_dye_slimeballs");
*/
});